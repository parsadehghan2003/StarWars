package com.parsadehghan.navigator

@JvmInline
value class DestinationRoute(val route: String)
