plugins {
    id("com.parsadehghan.gradle.android.library")
}

android {
    namespace = "com.parsadehghan.SnappFoodParsa.resources"
}
