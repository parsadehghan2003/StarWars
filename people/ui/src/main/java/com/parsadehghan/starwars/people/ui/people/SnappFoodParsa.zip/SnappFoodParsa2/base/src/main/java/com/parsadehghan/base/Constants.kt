package com.parsadehghan.base

object Constants {
    var BASE_URL = "https://swapi.dev/api/"
}