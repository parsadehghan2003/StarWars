package com.parsadehghan.snappfoodparsa

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHost
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import com.parsadehghan.snappfoodparsa.people.ui.GRAPH_PEOPLE_ROUTE
import com.parsadehghan.snappfoodparsa.people.ui.navigateToPeopleDetailScreen
import com.parsadehghan.snappfoodparsa.people.ui.peopleGraph

@Composable
fun SnappFoodParsaNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = GRAPH_PEOPLE_ROUTE.route,
        modifier = modifier,
    ) {
        peopleGraph(
            onPeopleClick = { rootRoute, peopleId ->
                navController.navigateToPeopleDetailScreen(rootRoute,peopleId)
            }
        )
    }

}