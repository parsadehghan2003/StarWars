package com.parsadehghan.snappfoodparsa.people.ui.people

import com.parsadehghan.snappfoodparsa.core.Character
import com.parsadehghan.snappfoodparsa.core.CharacterDetail
import com.parsadehghan.snappfoodparsa.people.domian.GetCharacterDetailsObject

/**
 * A sealed hierarchy describing the state of the text generation.
 */

data class PeopleDetailUiState(
    val isLoading: Boolean,
    val errorMessage: String? = null,
    val characterDetail: GetCharacterDetailsObject.GetCharacterDetailsResponse? = null
)