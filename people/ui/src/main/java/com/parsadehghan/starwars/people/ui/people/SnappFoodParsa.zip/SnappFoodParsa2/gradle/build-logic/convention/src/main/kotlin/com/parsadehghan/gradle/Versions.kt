package com.parsadehghan.gradle

object Versions {
  const val COMPILE_SDK = 35
  const val MIN_SDK = 21
  const val TARGET_SDK = 35
}
