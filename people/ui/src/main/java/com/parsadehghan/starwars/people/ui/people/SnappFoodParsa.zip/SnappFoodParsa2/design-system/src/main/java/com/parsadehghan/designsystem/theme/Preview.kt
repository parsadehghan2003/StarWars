package com.parsadehghan.designsystem.theme

import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable

@Composable
fun PreviewSnappFoodParsaTheme(content: @Composable () -> Unit) {
  SnappFoodParsaTheme {
    Surface {
      content()
    }
  }
}
