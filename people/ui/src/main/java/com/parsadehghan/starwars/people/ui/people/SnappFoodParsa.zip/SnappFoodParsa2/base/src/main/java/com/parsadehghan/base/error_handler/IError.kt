package com.parsadehghan.base.error_handler

interface IError {
    fun createError() : ErrorModel
}