plugins {
    id("com.parsadehghan.gradle.jvm.library")

}
dependencies{
    "implementation"(libs.coroutines)
    "implementation"(libs.gson)

}